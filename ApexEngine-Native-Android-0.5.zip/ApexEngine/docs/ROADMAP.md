# Apex Engine roadmap

## 0.1 Native foundation
Core loop, math, vehicle dynamics, procedural track, race state, Android EGL/GLES entry.

## 0.2 Renderer
Camera matrices, mesh buffers, procedural car/track meshes, materials, lighting, depth, shadows.

## 0.3 Driving
Four independent tyres, suspension travel, load transfer, combined slip, drivetrain, gearbox, differential, aero balance, surface friction.

## 0.4 Racing
Spline racing line, AI throttle/brake/steer, grid, countdown, sector/lap timing, overtaking and track limits.

## 0.5 Mobile feel — current work
Multitouch steering/throttle/brake, stable Android render thread lifecycle, 120 Hz simulation, mobile-safe rendering and regression tests.

## 0.6 Race presentation
HUD, countdown, timing tower, start lights, trackside objects, curbs, barriers, camera modes, pause/restart flow.

## 0.7 Advanced vehicle systems
Tyre compounds, tyre temperature/wear, brake temperature, ERS/DRS-style original systems, pit limiter, damage model.

## 0.8 Full game
Multiple circuits, qualifying, race weekends, weather, career, championships, garage, upgrades, progression, replay and saves.
