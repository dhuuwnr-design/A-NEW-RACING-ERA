# A New Racing Era — Apex Engine

A purpose-built Android-first racing game built on a custom native C++ engine.

**Engine:** Apex Engine  
**Runtime:** custom C++17  
**Graphics:** OpenGL ES 3  
**Android:** Java Activity + JNI + EGL  
**No Unity / No Godot runtime**

## Current engine milestone — 0.5
- Fixed-step 120 Hz vehicle simulation
- Four-wheel tyre force model
- Per-wheel normal load, slip angle, slip ratio and suspension compression
- Front/rear load transfer and aerodynamic downforce
- Rear-wheel drivetrain and sequential gearbox model
- Drag and rolling resistance
- Procedural closed circuit
- Track-width / boundary response
- Independent lap tracking for every opponent
- Live race position calculation
- 7 engine-side AI opponents
- Curvature-aware AI braking
- OpenGL ES 3 renderer
- 3D track ribbon and cars
- Android touch input
- Automated host regression tests

## Host validation
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
./build/tests/apex_physics_tests
```

The Android build is performed by GitHub Actions using the Android SDK/NDK on a hosted runner.

## Project direction
Apex Engine is being built as the complete racing runtime:
- core runtime and memory ownership
- vehicle and tyre physics
- track and racing systems
- AI
- rendering and materials
- audio
- touch controls
- race weekends
- career/championships
- upgrades
- weather
- damage
- replay
- mobile optimization

This repository is the real engine source. It is not being presented as a finished commercial-scale game yet.
