#include "physics/vehicle.h"
#include "racing/track.h"
#include "core/engine.h"
#include <cmath>
#include <iostream>
using namespace apex;

static VehicleInput trackFollowInput(const Engine& engine){
    const auto near=engine.track().nearest(engine.vehicle().transform.position);
    const float step=engine.track().length()/static_cast<float>(engine.track().samples().size());
    size_t idx=static_cast<size_t>(near.distance/step)+8;
    idx=std::min(idx,engine.track().samples().size()-1);
    const auto target=engine.track().samples()[idx].position;
    const auto to=target-engine.vehicle().transform.position;
    const float desired=std::atan2(to.x,to.z);
    const float steer=clampf(wrapAngle(desired-engine.vehicle().transform.yaw)*2.0f,-1.f,1.f);
    return {0.95f,0.f,steer,false};
}
static bool ok(bool condition,const char*message){
    if(!condition) std::cerr<<"TEST FAILURE: "<<message<<"\n";
    return condition;
}

int main(){
    Track t; t.buildProcedural();
    if(!ok(t.samples().size()==240,"track sample count") || !ok(t.length()>100.f,"track length") || !ok(t.halfWidth()>0.f,"track width")) return 1;
    if(!ok(t.isOnTrack(t.samples()[0].position),"start is on track")) return 1;

    VehicleDynamics straight;
    VehicleState s; straight.reset(t.samples()[0].position,0); s=straight.state();
    VehicleInput full; full.throttle=1.f;
    for(int n=0;n<1200;n++) straight.step(s,full,1.f/120.f);
    if(!ok(s.distance>100.f,"straight distance") || !ok(s.velocity.length()>5.f,"straight speed") || !ok(s.velocity.length()<=95.1f,"speed cap")) return 1;
    for(const auto&w:s.wheels) if(!ok(std::isfinite(w.normalLoad)&&w.normalLoad>0.f,"wheel load")) return 1;

    VehicleDynamics corner;
    VehicleState cs; corner.reset(t.samples()[0].position,0); cs=corner.state();
    VehicleInput turn; turn.throttle=0.8f; turn.steer=0.65f;
    for(int n=0;n<600;n++) corner.step(cs,turn,1.f/120.f);
    if(!ok(std::isfinite(cs.transform.yaw)&&std::isfinite(cs.yawRate),"corner stability")) return 1;
    if(!ok(std::abs(cs.wheels[0].slipAngle)>0.001f || std::abs(cs.wheels[2].slipAngle)>0.001f,"steering slip")) return 1;

    Engine engine;
    if(!ok(engine.initialize(),"engine initialization")) return 1;
    if(!ok(engine.opponents().size()==7,"seven opponents")) return 1;
    if(!ok(engine.race().position>=1 && engine.race().position<=8,"initial position")) return 1;

    for(int n=0;n<12000 && engine.race().state!=RaceState::Finished;n++)
        engine.update(1.f/60.f,trackFollowInput(engine));

    if(!ok(engine.vehicle().distance>500.f,"race distance")) return 1;
    if(!ok(engine.race().state==RaceState::Finished,"five-lap finish")) return 1;
    if(!ok(engine.race().lap==engine.race().totalLaps,"finish lap")) return 1;
    if(!ok(engine.race().position>=1 && engine.race().position<=8,"finish position")) return 1;

    std::cout<<"APEX ENGINE 0.5 TESTS PASS\n"
             <<"track_length="<<t.length()
             <<" straight_distance="<<s.distance
             <<" finish_position="<<engine.race().position
             <<" laps="<<engine.race().lap
             <<" opponents="<<engine.opponents().size()<<"\n";
}
