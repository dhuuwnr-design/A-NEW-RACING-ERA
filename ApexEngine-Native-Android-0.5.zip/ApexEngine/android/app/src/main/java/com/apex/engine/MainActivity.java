package com.apex.engine;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public final class MainActivity extends Activity implements SurfaceHolder.Callback {
    private SurfaceView view;
    private volatile boolean running;
    private volatile float throttle, brake, steer;
    private Thread renderThread;
    private int steerPointer = -1, throttlePointer = -1, brakePointer = -1;

    static { System.loadLibrary("apex_android"); }
    private static native void nativeInit(Surface surface);
    private static native void nativeResize(int width, int height);
    private static native void nativeFrame(float throttle, float brake, float steer);
    private static native void nativeShutdown();

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setFlags(1024, 1024);
        view = new SurfaceView(this);
        view.getHolder().addCallback(this);
        view.setFocusable(true);
        setContentView(view);
    }

    @Override public void surfaceCreated(SurfaceHolder holder) {
        nativeInit(holder.getSurface());
        running = true;
        renderThread = new Thread(() -> {
            while (running) {
                nativeFrame(throttle, brake, steer);
                try { Thread.sleep(8L); }
                catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            }
        }, "ApexRenderThread");
        renderThread.start();
    }

    private void recalcControls() {
        steer = steerPointer >= 0 ? steer : 0f;
        throttle = throttlePointer >= 0 ? 1f : 0f;
        brake = brakePointer >= 0 ? 1f : 0f;
    }

    private void assignPointer(int pointerId, float x, float y) {
        float w = Math.max(1f, view.getWidth());
        float h = Math.max(1f, view.getHeight());
        if (x < w * 0.42f && steerPointer < 0) {
            steerPointer = pointerId;
            steer = Math.max(-1f, Math.min(1f, (x / (w * 0.42f) - 0.5f) * 2f));
        } else if (x > w * 0.58f && y > h * 0.45f && throttlePointer < 0) {
            throttlePointer = pointerId;
        } else if (brakePointer < 0) {
            brakePointer = pointerId;
        }
        recalcControls();
    }

    private void releasePointer(int pointerId) {
        if (pointerId == steerPointer) steerPointer = -1;
        if (pointerId == throttlePointer) throttlePointer = -1;
        if (pointerId == brakePointer) brakePointer = -1;
        recalcControls();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            assignPointer(event.getPointerId(index), event.getX(index), event.getY(index));
            return true;
        }
        if (action == MotionEvent.ACTION_MOVE) {
            if (steerPointer >= 0) {
                int p = event.findPointerIndex(steerPointer);
                if (p >= 0) {
                    float w = Math.max(1f, view.getWidth());
                    steer = Math.max(-1f, Math.min(1f, (event.getX(p) / (w * 0.42f) - 0.5f) * 2f));
                }
            }
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            releasePointer(event.getPointerId(index));
            return true;
        }
        return true;
    }

    @Override public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        nativeResize(width, height);
    }

    @Override public void surfaceDestroyed(SurfaceHolder holder) {
        running = false;
        if (renderThread != null) {
            try { renderThread.join(500L); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            renderThread = null;
        }
        nativeShutdown();
        steerPointer = throttlePointer = brakePointer = -1;
        recalcControls();
    }
}
