#include <jni.h>
#include <android/native_window_jni.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include "core/engine.h"
#include "render/opengl_renderer.h"
static EGLDisplay d=EGL_NO_DISPLAY; static EGLSurface s=EGL_NO_SURFACE; static EGLContext c=EGL_NO_CONTEXT; static ANativeWindow* w=nullptr;
static apex::Engine e; static apex::OpenGLRenderer renderer; static bool ready=false;
extern "C" JNIEXPORT void JNICALL Java_com_apex_engine_MainActivity_nativeInit(JNIEnv* env,jclass,jobject surface){
 if(ready)return; w=ANativeWindow_fromSurface(env,surface); d=eglGetDisplay(EGL_DEFAULT_DISPLAY); if(d==EGL_NO_DISPLAY)return; eglInitialize(d,nullptr,nullptr);
 const EGLint a[]={EGL_RENDERABLE_TYPE,EGL_OPENGL_ES3_BIT,EGL_SURFACE_TYPE,EGL_WINDOW_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_DEPTH_SIZE,24,EGL_NONE};
 EGLConfig cfg{};EGLint n=0;eglChooseConfig(d,a,&cfg,1,&n);const EGLint ca[]={EGL_CONTEXT_CLIENT_VERSION,3,EGL_NONE};c=eglCreateContext(d,cfg,EGL_NO_CONTEXT,ca);s=eglCreateWindowSurface(d,cfg,w,nullptr);eglMakeCurrent(d,s,s,c);e.initialize();ready=renderer.initialize(d,s,c,ANativeWindow_getWidth(w),ANativeWindow_getHeight(w));
}
extern "C" JNIEXPORT void JNICALL Java_com_apex_engine_MainActivity_nativeResize(JNIEnv*,jclass,jint ww,jint hh){if(ready)renderer.resize(ww,hh);}
extern "C" JNIEXPORT void JNICALL Java_com_apex_engine_MainActivity_nativeFrame(JNIEnv*,jclass,jfloat t,jfloat b,jfloat st){if(!ready)return;e.update(1.f/60.f,{t,b,st,false});renderer.render(e);eglSwapBuffers(d,s);}
extern "C" JNIEXPORT void JNICALL Java_com_apex_engine_MainActivity_nativeShutdown(JNIEnv*,jclass){if(!ready)return;renderer.shutdown();eglMakeCurrent(d,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);eglDestroySurface(d,s);eglDestroyContext(d,c);eglTerminate(d);if(w)ANativeWindow_release(w);d=EGL_NO_DISPLAY;s=EGL_NO_SURFACE;c=EGL_NO_CONTEXT;w=nullptr;ready=false;}
