#pragma once
#include <cmath>
#include <algorithm>
namespace apex {
struct Vec2 { float x{},y{}; };
struct Vec3 {
 float x{},y{},z{};
 Vec3 operator+(const Vec3&o)const{return{x+o.x,y+o.y,z+o.z};}
 Vec3 operator-(const Vec3&o)const{return{x-o.x,y-o.y,z-o.z};}
 Vec3 operator*(float s)const{return{x*s,y*s,z*s};}
 Vec3& operator+=(const Vec3&o){x+=o.x;y+=o.y;z+=o.z;return *this;}
 float length()const{return std::sqrt(x*x+y*y+z*z);}
 Vec3 normalized()const{float l=length();return l>1e-6f?*this*(1.f/l):Vec3{};}
 static float dot(const Vec3&a,const Vec3&b){return a.x*b.x+a.y*b.y+a.z*b.z;}
 static Vec3 cross(const Vec3&a,const Vec3&b){return{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
};
struct Transform { Vec3 position{}; float yaw{}; };
inline float clampf(float v,float a,float b){return std::max(a,std::min(b,v));}
inline float lerpf(float a,float b,float t){return a+(b-a)*t;}
inline float wrapAngle(float a){while(a>3.14159265f)a-=6.2831853f;while(a<-3.14159265f)a+=6.2831853f;return a;}
}
