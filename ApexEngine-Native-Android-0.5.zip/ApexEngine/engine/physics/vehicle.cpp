#include "physics/vehicle.h"
#include <algorithm>
#include <cmath>
namespace apex {
namespace {
constexpr float G=9.81f;
constexpr float PI=3.14159265359f;
struct WheelGeom { float x; float y; bool front; };
const WheelGeom W[4]={{1.8f,0.95f,true},{1.8f,-0.95f,true},{-1.8f,0.95f,false},{-1.8f,-0.95f,false}};
}
VehicleDynamics::VehicleDynamics(){staticFrontLoad_=mass_*G*0.46f;staticRearLoad_=mass_*G*0.54f;reset({},0);}
void VehicleDynamics::reset(const Vec3&p,float yaw){state_={};state_.transform.position=p;state_.transform.yaw=yaw;state_.rpm=900;state_.gear=1;for(auto&w:state_.wheels)w.omega=900.f*2.f*PI/60.f;}
void VehicleDynamics::step(VehicleState&s,const VehicleInput&i,float dt){
 const float c=std::cos(s.transform.yaw),sn=std::sin(s.transform.yaw);
 const Vec3 forward{sn,0,c}, right{c,0,-sn};
 const float steer=clampf(i.steer,-1.f,1.f)*maxSteer_;
 const float speed=std::max(0.f,s.velocity.length());
 const float vf=Vec3::dot(s.velocity,forward);
 const float vl=Vec3::dot(s.velocity,right);
 const float downforce=aeroCoeff_*speed*speed;
 const float drag=dragCoeff_*speed*speed;
 const float longitudinalAccel=(speed>1.f?0.f:0.f);
 (void)longitudinalAccel;
 // Approximate load transfer from longitudinal acceleration and lateral acceleration.
 const float estimatedAx=(i.throttle*maxEngineForce_-i.brake*brakeForce_-drag)/mass_;
 const float estimatedAy=std::abs(vf*vf*std::tan(steer)/wheelBase_);
 const float frontBase=staticFrontLoad_+downforce*0.46f;
 const float rearBase=staticRearLoad_+downforce*0.54f;
 float frontLoad=frontBase - mass_*estimatedAx*cgHeight_/wheelBase_;
 float rearLoad=rearBase + mass_*estimatedAx*cgHeight_/wheelBase_;
 frontLoad=std::max(300.f,frontLoad); rearLoad=std::max(300.f,rearLoad);
 const float latTransfer=mass_*estimatedAy*cgHeight_/track_;
 const float loads[4]={std::max(120.f,frontLoad*0.5f-latTransfer*0.5f),std::max(120.f,frontLoad*0.5f+latTransfer*0.5f),std::max(120.f,rearLoad*0.5f-latTransfer*0.5f),std::max(120.f,rearLoad*0.5f+latTransfer*0.5f)};
 Vec3 totalLocal{0,0,0}; float yawMoment=0.f;
 const float wheelTorque=std::max(0.f,vf)*42.f + 110.f;
 const float gearRatio[9]={0.f,3.10f,2.20f,1.65f,1.32f,1.08f,0.91f,0.78f,0.68f};
 const float finalDrive=3.25f;
 const float engineForce=i.throttle*maxEngineForce_*(gearRatio[s.gear]*finalDrive/3.1f);
 for(int wi=0;wi<4;wi++){
  auto &w=s.wheels[wi]; const auto &g=W[wi];
  const float wheelYaw=g.front?steer:0.f;
  const float wc=std::cos(wheelYaw), ws=std::sin(wheelYaw);
  // Velocity at wheel in body coordinates. x is forward, y is left.
  const float wheelVx=vf - s.yawRate*g.y;
  const float wheelVy=vl + s.yawRate*g.x;
  const float vx=wheelVx*wc + wheelVy*ws;
  const float vy=-wheelVx*ws + wheelVy*wc;
  const float denom=std::max(2.f,std::abs(vx));
  const float slipAngle=std::atan2(vy,denom);
  const float targetOmega=vx/wheelRadius_;
  float driveForce=(wi>=2)?engineForce*0.5f:0.f;
  if(i.handbrake && wi>=2) driveForce=0.f;
  const float brakeForce=i.brake*brakeForce_*0.25f;
  const float requestedLong=driveForce - (vx>0.5f?brakeForce:0.f);
  const float requestedLat=-cornerStiffness_*slipAngle*loads[wi];
  const float maxForce=loads[wi]*tireMu_;
  const float mag=std::sqrt(requestedLong*requestedLong+requestedLat*requestedLat);
  const float scale=mag>maxForce?maxForce/mag:1.f;
  const float fx=requestedLong*scale, fy=requestedLat*scale;
  // Rotate wheel forces back to body axes.
  const float bodyFx=fx*wc-fy*ws, bodyFy=fx*ws+fy*wc;
  totalLocal.x+=bodyFx; totalLocal.y+=bodyFy;
  yawMoment += g.x*bodyFy - g.y*bodyFx;
  w.normalLoad=loads[wi]; w.longitudinalForce=fx; w.lateralForce=fy; w.slipAngle=slipAngle;
  w.slipRatio=(w.omega*wheelRadius_-vx)/denom;
  w.suspensionCompression=clampf(loads[wi]/(mass_*G/4.f)-1.f,-0.35f,0.35f);
  const float wheelAccel=(driveForce - (vx>0.5f?brakeForce:0.f) - w.omega*1.8f)/std::max(0.1f,mass_*0.25f*wheelRadius_);
  w.omega += wheelAccel*dt;
  w.omega=std::max(0.f,w.omega);
 }
 // Rear-wheel drive + body drag. Air resistance opposes velocity.
 const float fx=totalLocal.x-drag;
 const float fy=totalLocal.y;
 const float ax=fx/mass_, ay=fy/mass_;
 s.yawRate += (yawMoment/(mass_*(wheelBase_*wheelBase_+track_*track_)*0.28f) - s.yawRate*1.45f)*dt;
 s.transform.yaw=wrapAngle(s.transform.yaw+s.yawRate*dt);
 const float nc=std::cos(s.transform.yaw), ns=std::sin(s.transform.yaw);
 const Vec3 nf{ns,0,nc}, nr{nc,0,-ns};
 s.velocity += (nf*ax + nr*ay)*dt;
 // Rolling resistance keeps a released car from coasting forever.
 if(i.throttle<0.01f && i.brake<0.01f){float v=s.velocity.length();if(v>0.1f)s.velocity=s.velocity-s.velocity.normalized()*std::min(v,1.4f*dt);}
 float v=s.velocity.length();
 if(v>95.f)s.velocity=s.velocity.normalized()*95.f;
 s.transform.position += s.velocity*dt;
 s.distance += std::max(0.f,Vec3::dot(s.velocity,nf))*dt;
 // Simple sequential gearbox from wheel speed, with engine braking on lift.
 const float wheelRpm=v/(2.f*PI*wheelRadius_)*60.f;
 s.rpm=std::clamp(wheelRpm*gearRatio[s.gear]*finalDrive,900.f,7800.f);
 if(s.rpm>7350.f && s.gear<8) s.gear++;
 else if(s.rpm<2200.f && s.gear>1) s.gear--;
 if(i.throttle<0.01f && i.brake<0.01f) s.rpm=std::max(900.f,s.rpm-220.f*dt);
}
}
