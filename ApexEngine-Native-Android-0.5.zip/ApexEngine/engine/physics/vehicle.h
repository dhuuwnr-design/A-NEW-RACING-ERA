#pragma once
#include "math/math.h"
namespace apex {
struct VehicleInput { float throttle{}, brake{}, steer{}; bool handbrake{}; };
struct WheelState {
 float omega{};
 float slipRatio{};
 float slipAngle{};
 float normalLoad{};
 float longitudinalForce{};
 float lateralForce{};
 float suspensionCompression{};
};
struct VehicleState {
 Transform transform{};
 Vec3 velocity{};
 float yawRate{};
 float rpm{900};
 int gear{1};
 float distance{};
 WheelState wheels[4]{};
};
class VehicleDynamics {
public:
 VehicleDynamics();
 void reset(const Vec3& position,float yaw);
 void step(VehicleState& s,const VehicleInput& input,float dt);
 const VehicleState& state()const{return state_;}
private:
 VehicleState state_{};
 float mass_=820.f, wheelBase_=3.6f, track_=1.9f, cgHeight_=0.32f;
 float wheelRadius_=0.33f, maxEngineForce_=10500.f, brakeForce_=18000.f;
 float tireMu_=1.72f, cornerStiffness_=10.5f, dragCoeff_=0.42f, aeroCoeff_=0.78f;
 float maxSteer_=0.52f, staticFrontLoad_=0.f, staticRearLoad_=0.f;
};
}
