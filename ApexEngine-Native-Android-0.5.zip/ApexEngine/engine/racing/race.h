#pragma once
#include "physics/vehicle.h"
#include "racing/track.h"
#include <vector>
namespace apex {
enum class RaceState{Grid,Countdown,Racing,Finished};
struct RaceData{RaceState state=RaceState::Grid;int lap=1,totalLaps=5,position=1;float elapsed=0;float lastLap=0;float playerProgress=0;};
class RaceDirector{
public:
 void start(int laps);
 void update(float dt,const VehicleState&car,const std::vector<VehicleState>&opponents,const Track&t);
 const RaceData&data()const{return d_;}
private:
 RaceData d_{};
 float lastTrackProgress_{};
 int completedLaps_{};
 std::vector<float> opponentLastProgress_;
 std::vector<int> opponentLaps_;
};
}
