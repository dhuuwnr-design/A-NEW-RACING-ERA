#pragma once
#include "math/math.h"
#include <vector>
namespace apex {
struct TrackSample{Vec3 position;Vec3 tangent;float distance{};};
class Track {
 std::vector<TrackSample> samples_; float length_{}; float halfWidth_{6.0f};
public:
 void buildProcedural();
 const std::vector<TrackSample>& samples()const{return samples_;}
 float length()const{return length_;}
 float halfWidth()const{return halfWidth_;}
 bool isOnTrack(const Vec3&p,float margin=0.f)const{return nearest(p).distance <= halfWidth_+margin;}
 TrackSample nearest(const Vec3&p)const;
};
}
