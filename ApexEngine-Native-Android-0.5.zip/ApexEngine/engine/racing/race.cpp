#include "racing/race.h"
#include <algorithm>
#include <cmath>
namespace apex {
void RaceDirector::start(int laps){
 d_={}; d_.state=RaceState::Racing; d_.totalLaps=std::max(1,laps); d_.lap=1;
 lastTrackProgress_=0.f; completedLaps_=0; opponentLastProgress_.clear(); opponentLaps_.clear();
}
void RaceDirector::update(float dt,const VehicleState&car,const std::vector<VehicleState>&opponents,const Track&t){
 if(d_.state!=RaceState::Racing || t.length()<=0.f)return;
 d_.elapsed+=dt;
 const auto ps=t.nearest(car.transform.position);
 const float playerTrack=std::clamp(ps.distance/t.length(),0.f,0.99999f);
 if(playerTrack < lastTrackProgress_-0.5f && car.velocity.length()>2.f){
  ++completedLaps_; d_.lastLap=d_.elapsed; d_.lap=completedLaps_+1;
  if(completedLaps_>=d_.totalLaps){d_.lap=d_.totalLaps; d_.state=RaceState::Finished;}
 }
 lastTrackProgress_=playerTrack;
 d_.playerProgress=completedLaps_+playerTrack;
 if(opponentLastProgress_.size()!=opponents.size()){
  opponentLastProgress_.assign(opponents.size(),0.f); opponentLaps_.assign(opponents.size(),0);
 }
 std::vector<float> progress(opponents.size());
 for(size_t n=0;n<opponents.size();++n){
  float p=std::clamp(t.nearest(opponents[n].transform.position).distance/t.length(),0.f,0.99999f);
  if(p < opponentLastProgress_[n]-0.5f && opponents[n].velocity.length()>2.f) opponentLaps_[n]++;
  opponentLastProgress_[n]=p;
  progress[n]=opponentLaps_[n]+p;
 }
 int ahead=0;
 for(size_t n=0;n<opponents.size();++n){
  if(progress[n]>d_.playerProgress+0.001f || (std::abs(progress[n]-d_.playerProgress)<=0.001f && opponents[n].distance>car.distance)) ++ahead;
 }
 d_.position=ahead+1;
}
}
