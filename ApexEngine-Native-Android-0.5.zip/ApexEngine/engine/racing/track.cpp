#include "racing/track.h"
#include <cmath>
namespace apex {
void Track::buildProcedural(){
 samples_.clear(); length_=0; const int n=240; Vec3 prev{};
 for(int i=0;i<n;i++){float t=6.2831853f*i/n; float r=70.f+10.f*std::sin(2*t)+7.f*std::sin(3*t+0.7f); Vec3 p{r*std::sin(t),0, r*std::cos(t)}; Vec3 q{(r+0.2f)*std::sin(t+0.01f),0,(r+0.2f)*std::cos(t+0.01f)}; Vec3 tan=(q-p).normalized(); if(i){length_+=(p-prev).length();} samples_.push_back({p,tan,length_});prev=p;}
}
TrackSample Track::nearest(const Vec3&p)const{TrackSample best{};float d=1e30f;for(auto&s:samples_){float ds=(s.position-p).length();if(ds<d){d=ds;best=s;}}return best;}
}
