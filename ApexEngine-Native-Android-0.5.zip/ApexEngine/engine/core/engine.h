#pragma once
#include "physics/vehicle.h"
#include "racing/track.h"
#include "racing/race.h"
#include <vector>
namespace apex {
class Engine {
public:
 struct Opponent { VehicleDynamics dynamics; VehicleState state{}; float lane{}; };
private:
 VehicleDynamics vehicle_; VehicleState state_{}; Track track_; RaceDirector race_; std::vector<Opponent> opponents_; float accumulator_{}; static constexpr float fixedDt=1.f/120.f;
public:
 bool initialize(); void update(float dt,const VehicleInput&input); const VehicleState&vehicle()const{return state_;} const RaceData&race()const{return race_.data();} const Track&track()const{return track_;} const std::vector<Opponent>&opponents()const{return opponents_;}
};
}
