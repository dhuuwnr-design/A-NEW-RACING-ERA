#include "core/engine.h"
#include <cmath>
namespace apex {
bool Engine::initialize(){
 track_.buildProcedural();
 const auto start=track_.samples().front();
 vehicle_.reset(start.position+Vec3{0,0.4f,0},std::atan2(start.tangent.x,start.tangent.z)); state_=vehicle_.state();
 opponents_.clear();
 for(int n=0;n<7;n++){ Opponent o; auto base=track_.samples()[0].position; float offset=((n%3)-1)*3.0f; float back=-(n/3+1)*7.0f; auto t=track_.samples()[0].tangent; auto side=Vec3::cross({0,1,0},t).normalized(); o.lane=offset; o.dynamics.reset(base + side*offset - t*back,std::atan2(t.x,t.z)); o.state=o.dynamics.state(); opponents_.push_back(o); }
 race_.start(5); return true;
}
void Engine::update(float dt,const VehicleInput&i){
 accumulator_+=dt;
 while(accumulator_>=fixedDt){
  vehicle_.step(state_,i,fixedDt);
  {
   auto near=track_.nearest(state_.transform.position);
   float lateralError=Vec3::dot(state_.transform.position-near.position,Vec3::cross({0,1,0},near.tangent));
   float limit=track_.halfWidth()+0.8f;
   if(std::abs(lateralError)>limit){
    Vec3 side=Vec3::cross({0,1,0},near.tangent).normalized();
    float excess=std::abs(lateralError)-limit;
    state_.transform.position = state_.transform.position - side*(lateralError>0.f?1.f:-1.f)*std::min(excess,1.8f)*0.18f;
    state_.velocity = state_.velocity*0.985f;
   }
  }
  for(auto& o:opponents_){
   auto near=track_.nearest(o.state.transform.position);
   auto idx=static_cast<size_t>(near.distance/(track_.length()/track_.samples().size())); idx=std::min(idx+4,track_.samples().size()-1);
   auto target=track_.samples()[idx].position; auto to=(target-o.state.transform.position);
   float desired=std::atan2(to.x,to.z); float steer=clampf(wrapAngle(desired-o.state.transform.yaw)*2.2f,-1.f,1.f);
   const auto& future=track_.samples()[std::min(idx+10,track_.samples().size()-1)];
   float curvature=std::abs(wrapAngle(std::atan2(future.tangent.x,future.tangent.z)-std::atan2(near.tangent.x,near.tangent.z)));
   float brake=clampf((curvature-0.22f)*1.8f + (std::abs(steer)-0.72f)*0.8f,0.f,0.8f);
   VehicleInput ai; ai.throttle=clampf(0.88f - brake*0.65f,0.15f,0.92f); ai.steer=steer; ai.brake=brake;
   o.dynamics.step(o.state,ai,fixedDt);
  }
  std::vector<VehicleState> opponentStates; opponentStates.reserve(opponents_.size());
  for(const auto& o:opponents_) opponentStates.push_back(o.state);
  race_.update(fixedDt,state_,opponentStates,track_); accumulator_-=fixedDt;
 }
}
}
