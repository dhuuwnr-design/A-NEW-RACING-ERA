#include "render/opengl_renderer.h"
#include <cmath>
#include <vector>
#include <algorithm>
namespace apex {
namespace {
struct M4 { float v[16]{}; };
M4 identity(){M4 m{};m.v[0]=m.v[5]=m.v[10]=m.v[15]=1;return m;}
M4 mul(const M4&a,const M4&b){M4 r{};for(int c=0;c<4;c++)for(int r0=0;r0<4;r0++)for(int k=0;k<4;k++)r.v[c*4+r0]+=a.v[k*4+r0]*b.v[c*4+k];return r;}
M4 perspective(float fovy,float aspect,float zn,float zf){M4 m{};float f=1.f/std::tan(fovy*.5f);m.v[0]=f/aspect;m.v[5]=f;m.v[10]=(zf+zn)/(zn-zf);m.v[11]=-1;m.v[14]=(2*zf*zn)/(zn-zf);return m;}
M4 lookAt(Vec3 eye,Vec3 center,Vec3 up){Vec3 f=(center-eye).normalized(),s=Vec3::cross(f,up).normalized(),u=Vec3::cross(s,f);M4 m=identity();m.v[0]=s.x;m.v[1]=s.y;m.v[2]=s.z;m.v[4]=u.x;m.v[5]=u.y;m.v[6]=u.z;m.v[8]=-f.x;m.v[9]=-f.y;m.v[10]=-f.z;m.v[12]=-Vec3::dot(s,eye);m.v[13]=-Vec3::dot(u,eye);m.v[14]=Vec3::dot(f,eye);return m;}
M4 translate(Vec3 p){M4 m=identity();m.v[12]=p.x;m.v[13]=p.y;m.v[14]=p.z;return m;}
M4 scale(float x,float y,float z){M4 m=identity();m.v[0]=x;m.v[5]=y;m.v[10]=z;return m;}
M4 rotateY(float a){M4 m=identity();float c=std::cos(a),s=std::sin(a);m.v[0]=c;m.v[2]=-s;m.v[8]=s;m.v[10]=c;return m;}
GLuint shader(GLenum type,const char*src){GLuint s=glCreateShader(type);glShaderSource(s,1,&src,nullptr);glCompileShader(s);GLint ok=0;glGetShaderiv(s,GL_COMPILE_STATUS,&ok);if(!ok){glDeleteShader(s);return 0;}return s;}
}
bool OpenGLRenderer::createProgram(){
 const char*vs="#version 300 es\nlayout(location=0)in vec3 aPos;uniform mat4 uMvp;void main(){gl_Position=uMvp*vec4(aPos,1.0);} ";
 const char*fs="#version 300 es\nprecision mediump float;uniform vec3 uColor;out vec4 o;void main(){o=vec4(uColor,1.0);} ";
 GLuint v=shader(GL_VERTEX_SHADER,vs),f=shader(GL_FRAGMENT_SHADER,fs);if(!v||!f)return false;program_=glCreateProgram();glAttachShader(program_,v);glAttachShader(program_,f);glLinkProgram(program_);glDeleteShader(v);glDeleteShader(f);GLint ok=0;glGetProgramiv(program_,GL_LINK_STATUS,&ok);if(!ok)return false;uMvp_=glGetUniformLocation(program_,"uMvp");uColor_=glGetUniformLocation(program_,"uColor");return true;
}
bool OpenGLRenderer::initialize(EGLDisplay,EGLSurface,EGLContext,int width,int height){width_=std::max(1,width);height_=std::max(1,height);glViewport(0,0,width_,height_);glEnable(GL_DEPTH_TEST);glEnable(GL_CULL_FACE);glCullFace(GL_BACK);if(!createProgram())return false;glGenVertexArrays(1,&vao_);glGenBuffers(1,&vbo_);return true;}
void OpenGLRenderer::resize(int w,int h){width_=std::max(1,w);height_=std::max(1,h);glViewport(0,0,width_,height_);}
void OpenGLRenderer::drawStrip(const Engine& e,const float*mvp,float r,float g,float b){
 const auto&s=e.track().samples();std::vector<float> verts;verts.reserve(s.size()*6);for(size_t i=0;i<s.size();i++){auto&a=s[i];auto&n=s[(i+1)%s.size()];Vec3 t=(n.position-a.position).normalized();Vec3 side=Vec3::cross({0,1,0},t).normalized();float w=5.8f;Vec3 l=a.position+side*w,rp=a.position-side*w;l.y=.02f;rp.y=.02f;verts.insert(verts.end(),{l.x,l.y,l.z,rp.x,rp.y,rp.z});}
 glBindVertexArray(vao_);glBindBuffer(GL_ARRAY_BUFFER,vbo_);glBufferData(GL_ARRAY_BUFFER,verts.size()*sizeof(float),verts.data(),GL_DYNAMIC_DRAW);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);glEnableVertexAttribArray(0);glUseProgram(program_);glUniformMatrix4fv(uMvp_,1,GL_FALSE,mvp);glUniform3f(uColor_,r,g,b);glDrawArrays(GL_TRIANGLE_STRIP,0,(GLsizei)(verts.size()/3));
}
void OpenGLRenderer::drawCube(const Engine&e,const float*mvp,float r,float g,float b){(void)e;static const float q[]={-1,-1,-1, 1,-1,-1, 1,1,-1, -1,1,-1,  -1,-1,1, 1,-1,1, 1,1,1, -1,1,1,  -1,-1,-1, -1,1,-1, -1,1,1, -1,-1,1,  1,-1,-1, 1,1,-1, 1,1,1, 1,-1,1,  -1,1,-1, 1,1,-1, 1,1,1, -1,1,1,  -1,-1,-1, -1,-1,1, 1,-1,1, 1,-1,-1};glBindVertexArray(vao_);glBindBuffer(GL_ARRAY_BUFFER,vbo_);glBufferData(GL_ARRAY_BUFFER,sizeof(q),q,GL_STATIC_DRAW);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);glEnableVertexAttribArray(0);glUseProgram(program_);glUniformMatrix4fv(uMvp_,1,GL_FALSE,mvp);glUniform3f(uColor_,r,g,b);for(int i=0;i<6;i++)glDrawArrays(GL_TRIANGLE_FAN,i*4,4);}
void OpenGLRenderer::render(const Engine&e){
 glClearColor(.025f,.035f,.06f,1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
 const auto&car=e.vehicle();float yaw=car.transform.yaw;Vec3 f{std::sin(yaw),0,std::cos(yaw)};Vec3 eye=car.transform.position-f*11.f+Vec3{0,5.2f,0};Vec3 target=car.transform.position+f*12.f+Vec3{0,1,0};M4 vp=mul(perspective(1.05f,(float)width_/height_,.1f,500.f),lookAt(eye,target,{0,1,0}));
 M4 trackMvp=vp;drawStrip(e,trackMvp.v,.16f,.17f,.19f);
 // car body
 M4 carMvp=mul(vp,mul(translate(car.transform.position+Vec3{0,.65f,0}),mul(rotateY(yaw),scale(1.15f,.38f,2.15f))));drawCube(e,carMvp,.72f,.08f,.05f);
 // opponent field
 for(const auto& o:e.opponents()){
  float oy=o.state.transform.yaw;
  M4 omvp=mul(vp,mul(translate(o.state.transform.position+Vec3{0,.55f,0}),mul(rotateY(oy),scale(1.05f,.32f,1.95f))));
  drawCube(e,omvp,.06f,.24f,.68f);
 }
 // simple front wing / cockpit accent
 M4 wing=mul(vp,mul(translate(car.transform.position+f*1.85f+Vec3{0,.28f,0}),mul(rotateY(yaw),scale(1.55f,.08f,.22f))));drawCube(e,wing,.08f,.08f,.09f);
}
void OpenGLRenderer::shutdown(){if(vbo_)glDeleteBuffers(1,&vbo_);if(vao_)glDeleteVertexArrays(1,&vao_);if(program_)glDeleteProgram(program_);vbo_=vao_=program_=0;}
}
