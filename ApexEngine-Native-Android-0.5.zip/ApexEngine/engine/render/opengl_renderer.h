#pragma once
#include "core/engine.h"
#include <EGL/egl.h>
#include <GLES3/gl3.h>
namespace apex {
class OpenGLRenderer {
public:
 bool initialize(EGLDisplay display, EGLSurface surface, EGLContext context, int width, int height);
 void resize(int width, int height);
 void render(const Engine& engine);
 void shutdown();
private:
 GLuint program_{0}, vao_{0}, vbo_{0};
 GLint uMvp_{-1}, uColor_{-1};
 int width_{1}, height_{1};
 bool createProgram();
 void drawStrip(const Engine& engine, const float* mvp, float r,float g,float b);
 void drawCube(const Engine& engine, const float* mvp, float r,float g,float b);
};
}
