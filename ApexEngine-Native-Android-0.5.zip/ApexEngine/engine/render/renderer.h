#pragma once
namespace apex {
class Renderer { public: virtual ~Renderer()=default; virtual bool initialize(void*nativeWindow,int width,int height)=0; virtual void beginFrame()=0; virtual void drawFrame()=0; virtual void endFrame()=0; };
}
